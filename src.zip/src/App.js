// src/App.js
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import BookList from './components/BookList';
import SignUp from './components/SignUp';
import Login from './components/Login';
import Profile from './components/Profile';
import Book from './components/Book';
const App = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [user, setUser] = useState(() => {
    // Initialize user state from local storage
    const savedUser = localStorage.getItem('user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  // Effect to handle local storage updates
  useEffect(() => {
    const handleStorageChange = () => {
      const savedUser = localStorage.getItem('user');
      setUser(savedUser ? JSON.parse(savedUser) : null);
    };

    // Listen for storage changes
    window.addEventListener('storage', handleStorageChange);
    
    // Cleanup the event listener
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  return (
    <Router>
      <div className="app">
        <Header user={user} setUser={setUser} searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
        <Routes>
          <Route path="/" element={<BookList searchTerm={searchTerm} />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/login" element={<Login setUser={setUser} />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/book" element={<Book />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
