// src/components/Header.js
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate from react-router-dom
import './Header.css';
import logo from './library-logo.png'; // Import the logo image
import ProfilePicture from './ProfilePicture'; // Import the ProfilePicture component

const Header = ({ searchTerm, setSearchTerm }) => {
  const navigate = useNavigate(); // Initialize the navigate function
  const [user, setUser] = useState(null); // Initialize user state
  const [dropdownVisible, setDropdownVisible] = useState(false); // Add state for dropdown visibility

  useEffect(() => {
    // Check for user in local storage
    const loggedInUser = JSON.parse(localStorage.getItem('user'));
    setUser(loggedInUser); // Set the user state
  }, []); // Run only once on mount

  const handleLogout = () => {
    localStorage.removeItem('user'); // Clear user session
    setUser(null); // Update user state to null
    navigate('/login'); // Redirect to login page
  };

  const toggleDropdown = () => {
    setDropdownVisible((prev) => !prev); // Toggle dropdown visibility
  };

  const handleViewProfile = () => {
    navigate('/profile'); // Navigate to profile page
    setDropdownVisible(false); // Close dropdown
  };

  return (
    <header className="header">
      <div className="logo-container">
        <img 
          src={logo} 
          alt="Library Logo" 
          className="library-logo" 
          onClick={() => navigate('/')} // Navigate to BookList page
          style={{ cursor: 'pointer' }} // Change cursor to pointer to indicate it's clickable
        />
        <h1 
          className="library-name" 
          onClick={() => navigate('/')} // Navigate to BookList page
          style={{ cursor: 'pointer' }} // Change cursor to pointer
        >
          Database Library Project
        </h1>
      </div>
      <div className="header-actions">
        <input 
          type="text" 
          placeholder="Search for books..." 
          value={searchTerm} 
          onChange={(e) => setSearchTerm(e.target.value)} 
          className="search-input" 
        />
        {user ? (
          <div className="profile-container">
            <div onClick={toggleDropdown} style={{ cursor: 'pointer' }}>
              <ProfilePicture userId={user.id} /> {/* Show profile image only */}
            </div>
            {dropdownVisible && (
              <div className="dropdown-menu">
                <button onClick={handleViewProfile}>View Profile</button>
                <button onClick={handleLogout}>Sign Out</button>
              </div>
            )}
          </div>
        ) : (
          <button className="login-button" onClick={() => navigate('/login')}>
            Login
          </button>
        )}
      </div>
    </header>
  );
};

export default Header;
