import React, { useEffect, useState } from 'react';
import Default from "./default.png";
import './Profile.css';

const Profile = () => {
  const user = JSON.parse(localStorage.getItem('user'));

  const [userDetails, setUserDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [imageData, setImageData] = useState(null); // State for holding image data
  const [hasCheckedImage, setHasCheckedImage] = useState(false); // New state to track if image has been checked

  useEffect(() => {
    if (user) {
      // Fetch user details
      fetch(`http://localhost:5000/api/getUserDetails/${user.id}`)
        .then((response) => {
          if (!response.ok) {
            throw new Error(`Error: ${response.statusText}`);
          }
          return response.json();
        })
        .then((data) => {
          setUserDetails(data);
          setLoading(false);
        })
        .catch(() => {
          setLoading(false);
          setUserDetails(null); // Clear user details on error
        });
    } else {
      setLoading(false); // If no user is present
    }
  }, [user]);

  useEffect(() => {
    if (user && !hasCheckedImage) { // Only check if image has not been checked yet
      // Fetch profile picture on component mount
      fetch(`http://localhost:5000/api/getProfilePicture/${user.id}`)
        .then((response) => {
          if (!response.ok) {
            throw new Error(`Error fetching profile picture: ${response.statusText}`);
          }
          return response.json();
        })
        .then((data) => {
          if (data.image) {
            setImageData(data.image); // Set the image data from the response if it exists
          } else {
            setImageData(null); // Set to null if no image found, so default can be used
          }
          setHasCheckedImage(true); // Set the flag to true after checking
        })
        .catch(() => {
          setHasCheckedImage(true); // Ensure we mark the check as done even if there's an error
        });
    }
  }, [user, hasCheckedImage]);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const formData = new FormData();
      formData.append('profile_picture', file);

      // Upload the file
      fetch(`http://localhost:5000/api/uploadProfilePicture/${user.id}`, {
        method: 'POST',
        body: formData,
      })
        .then(response => response.json())
        .then(data => {
          if (data.message) {
            // Fetch the updated profile picture
            fetch(`http://localhost:5000/api/getProfilePicture/${user.id}`)
              .then((response) => {
                if (!response.ok) {
                  throw new Error(`Error fetching updated profile picture: ${response.statusText}`);
                }
                return response.json();
              })
              .then((data) => {
                setImageData(data.image || null); // Update the imageData state with the new picture or null
              });
          }
        });
    }
  };

  if (loading) {
    return <div style={{ textAlign: 'center', color: 'white' }}>Loading...</div>; // Display loading message
  }

  if (!user) {
    return <div>Please log in to view your profile.</div>;
  }

  return (
    <div className="profile-page">
      <h2 className="profile-title">Profile</h2>
      
      <div className="profile-content">
        <div className="profile-left">
          <img 
            src={imageData || Default} // Use imageData for profile picture, fall back to default if null
            alt="Profile"
            className="picture" 
          />
          <input 
            type="file" 
            accept="image/*" 
            onChange={handleFileChange}
            style={{ display: 'none' }} 
            id="file-input" 
          />
          <label htmlFor="file-input" className="change-pfp-btn">Change PFP</label>
        </div>
        
        <div className="profile-info">
          <p><strong>Name:</strong> {userDetails?.fname} {userDetails?.lname}</p>
          <p><strong>Email:</strong> {userDetails?.email}</p>
          <p><strong>Street:</strong> {userDetails?.street}</p>
          <p><strong>City:</strong> {userDetails?.city}</p>
          <p><strong>Postal Code:</strong> {userDetails?.postalCode}</p>
          <p><strong>Phone:</strong> {userDetails?.phone}</p>
        </div>
      </div>
    </div>
  );
};

export default Profile;
