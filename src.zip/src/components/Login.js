// src/components/Login.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for routing
import './Login.css'; // Ensure this file contains styles matching your theme

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [errorMessage, setErrorMessage] = useState(''); // State for error message
  const navigate = useNavigate(); // Initialize the navigate function

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    console.log('Login submitted:', formData);

    try {
      const response = await fetch('http://localhost:5000/api/login', { // Adjust your backend endpoint as necessary
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: formData.email,
          password: formData.password,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        console.log('Login successful!');
        localStorage.setItem('user', JSON.stringify(data.user)); // Save user data to local storage
        navigate('/'); // Navigate to the main page
      } else {
        console.log('Login failed:', data.error);
        setErrorMessage(data.error); // Set error message
        setFormData({ email: '', password: '' }); // Clear input fields
      }
    } catch (error) {
      console.error('Error during login:', error);
      setErrorMessage('An error occurred. Please try again.'); // Handle network errors
    }
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <h2>Log In</h2>
        <form onSubmit={handleSubmit}>
          <label>
            Email:
            <input 
              type="email" 
              name="email" 
              value={formData.email} 
              onChange={handleChange} 
              required 
            />
          </label>
          <label>
            Password:
            <input 
              type="password" 
              name="password" 
              value={formData.password} 
              onChange={handleChange} 
              required 
            />
          </label>
          {errorMessage && <p className="error-message">{errorMessage}</p>} {/* Display error message */}
          <button type="submit" className="submit-button">Log In</button>
        </form>
        <button 
          className="submit-button" 
          onClick={() => navigate('/signup')} // Navigate to signup page
          style={{ marginTop: '10px', backgroundColor: '#5C4033', color: '#FAF4E4' }} // Same styling as the submit button with slight adjustments
        >
          Go to Sign Up
        </button>
      </div>
    </div>
  );
};

export default Login;
