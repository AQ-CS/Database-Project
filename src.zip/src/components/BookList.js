import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './BookList.css';

const BookList = ({ searchTerm }) => {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/books');
        setBooks(response.data);
        console.log('Books fetched:', response.data); // Log the fetched books
      } catch (error) {
        console.error('Error fetching books:', error);
      }
    };

    fetchBooks();
  }, []);

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.author.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="book-list">
      {filteredBooks.length === 0 ? (
        <p>No books found matching your search criteria.</p>
      ) : (
        filteredBooks.map((book) => (
          <div key={book.id} className="book-item">
            <img 
              src={book.image ? book.image : './default.png'} 
              alt={book.title} 
              className="book-image" 
            />
            <div className="book-info">
              <h3>{book.title}</h3>
              <p><strong>Author:</strong> {book.author}</p>
              <p><strong>Description:</strong> {book.description}</p>
              <div className="quantity-container">
              <p><strong>Quantity: </strong>
                {book.copies_available > 0 ? (
                  book.copies_available
                ) : (
                  <span style={{ color: 'red' }}>Not Available Currently</span>
                )}
              </p>

              {book.copies_available > 0 && (
                <button className="borrow-button">Borrow</button>
              )}

              </div>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default BookList;
